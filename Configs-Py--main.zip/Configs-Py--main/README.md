Steps:
1.Download All File
2.Click Install All
3.Enjoy it

Made By BANTOR-Configs Teams
